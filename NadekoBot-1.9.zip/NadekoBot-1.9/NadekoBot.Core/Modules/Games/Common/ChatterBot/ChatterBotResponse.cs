﻿namespace NadekoBot.Modules.Games.Common.ChatterBot
{
    public class ChatterBotResponse
    {
        public string Convo_id { get; set; }
        public string BotSay { get; set; }
    }
}
